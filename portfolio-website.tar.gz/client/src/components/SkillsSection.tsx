import { motion } from "framer-motion";
import { Code, Globe, Brain, Database, Laptop, Server, Bot } from "lucide-react";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { useEffect, useState } from "react";

export default function SkillsSection() {
  const { ref, isVisible } = useScrollReveal();
  const [animateSkills, setAnimateSkills] = useState(false);

  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => setAnimateSkills(true), 500);
      return () => clearTimeout(timer);
    }
  }, [isVisible]);

  const skillCategories = [
    {
      title: "Programming Languages",
      icon: <Code className="w-5 h-5 text-white" />,
      color: "from-cyan-500 to-blue-600",
      skills: [
        { name: "Python", level: 90, color: "from-cyan-500 to-blue-600" },
        { name: "JavaScript", level: 88, color: "from-yellow-500 to-orange-600" },
        { name: "Java", level: 85, color: "from-red-500 to-pink-600" },
        { name: "C", level: 80, color: "from-blue-500 to-purple-600" }
      ]
    },
    {
      title: "Web Technologies",
      icon: <Globe className="w-5 h-5 text-white" />,
      color: "from-green-500 to-teal-600",
      skills: [
        { name: "React.js", level: 92, color: "from-cyan-500 to-blue-600" },
        { name: "Django", level: 88, color: "from-green-500 to-teal-600" },
        { name: "Node.js", level: 85, color: "from-green-600 to-emerald-600" },
        { name: "HTML5/CSS3", level: 95, color: "from-orange-500 to-red-600" }
      ]
    },
    {
      title: "AI/ML & Data Science",
      icon: <Brain className="w-5 h-5 text-white" />,
      color: "from-purple-500 to-pink-600",
      skills: [
        { name: "OpenCV", level: 87, color: "from-purple-500 to-pink-600" },
        { name: "TensorFlow", level: 82, color: "from-orange-500 to-red-600" },
        { name: "Pandas/NumPy", level: 90, color: "from-blue-500 to-indigo-600" },
        { name: "YOLOv8", level: 85, color: "from-green-500 to-cyan-600" }
      ]
    },
    {
      title: "Databases & Cloud",
      icon: <Database className="w-5 h-5 text-white" />,
      color: "from-indigo-500 to-purple-600",
      skills: [
        { name: "SQL", level: 88, color: "from-blue-500 to-cyan-600" },
        { name: "MongoDB", level: 83, color: "from-green-500 to-teal-600" },
        { name: "Google Cloud", level: 80, color: "from-yellow-500 to-orange-600" },
        { name: "AWS", level: 75, color: "from-orange-500 to-red-600" }
      ]
    }
  ];

  const specializations = [
    {
      title: "Frontend Development",
      icon: <Laptop className="w-8 h-8 text-white" />,
      color: "from-blue-500 to-cyan-600",
      description: "React, HTML5, CSS3, JavaScript, Responsive Design"
    },
    {
      title: "Backend Development",
      icon: <Server className="w-8 h-8 text-white" />,
      color: "from-green-500 to-teal-600",
      description: "Django, Node.js, Express.js, RESTful APIs"
    },
    {
      title: "AI & Machine Learning",
      icon: <Bot className="w-8 h-8 text-white" />,
      color: "from-purple-500 to-pink-600",
      description: "OpenCV, YOLOv8, TensorFlow, Computer Vision"
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: "easeOut" },
    },
  };

  return (
    <section id="skills" className="py-20 bg-slate-800/50" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            <span className="text-gradient">Technical Skills</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            A comprehensive overview of my technical expertise and proficiency levels
          </p>
        </motion.div>

        <motion.div
          className="grid lg:grid-cols-2 gap-12 mb-16"
          variants={containerVariants}
          initial="hidden"
          animate={isVisible ? "visible" : "hidden"}
        >
          {skillCategories.map((category, categoryIndex) => (
            <motion.div key={categoryIndex} variants={itemVariants}>
              <h3 className="text-2xl font-bold mb-8 flex items-center">
                <div className={`w-8 h-8 bg-gradient-to-r ${category.color} rounded-lg flex items-center justify-center mr-3`}>
                  {category.icon}
                </div>
                {category.title}
              </h3>
              <div className="space-y-6">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex} className="skill-item">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">{skill.name}</span>
                      <span className="text-cyan-400 font-mono text-sm">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <motion.div
                        className={`skill-bar bg-gradient-to-r ${skill.color} h-2 rounded-full`}
                        initial={{ width: 0 }}
                        animate={animateSkills ? { width: `${skill.level}%` } : { width: 0 }}
                        transition={{ duration: 2, delay: skillIndex * 0.2, ease: "easeOut" }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Skill Categories Grid */}
        <motion.div
          className="grid md:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          animate={isVisible ? "visible" : "hidden"}
        >
          {specializations.map((spec, index) => (
            <motion.div
              key={index}
              className="glass-morphism rounded-xl p-6 text-center hover:bg-white/10 transition-colors duration-300"
              variants={itemVariants}
              whileHover={{ y: -5, scale: 1.02 }}
              transition={{ duration: 0.3 }}
            >
              <div className={`w-16 h-16 bg-gradient-to-r ${spec.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                {spec.icon}
              </div>
              <h4 className="text-xl font-bold mb-2">{spec.title}</h4>
              <p className="text-gray-400 text-sm">{spec.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
