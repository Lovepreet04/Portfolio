# Portfolio Application

## Overview

This is a modern portfolio application built for Lovepreet Singh, a full-stack developer and AI enthusiast. The application is a single-page portfolio website showcasing personal information, projects, skills, experience, and contact details. It features a clean, professional design with smooth animations and interactive elements.

## System Architecture

The application follows a full-stack architecture with clear separation between client and server:

- **Frontend**: React-based single-page application with TypeScript
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Neon serverless connection
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **Build Tool**: Vite for development and production builds
- **Animation**: Framer Motion for smooth transitions and effects

## Key Components

### Frontend Architecture
- **React 18** with TypeScript for type safety
- **Wouter** for lightweight client-side routing
- **TanStack Query** for server state management
- **Framer Motion** for animations and micro-interactions
- **shadcn/ui** component library built on Radix UI primitives
- **Tailwind CSS** for utility-first styling

### Backend Architecture
- **Express.js** server with TypeScript
- **RESTful API** endpoints for contact form and resume download
- **Session management** with connect-pg-simple
- **Error handling** middleware for centralized error management

### UI Component System
- Comprehensive set of reusable components from shadcn/ui
- Custom portfolio-specific components (HeroSection, AboutSection, etc.)
- Responsive design with mobile-first approach
- Dark theme with custom color palette optimized for portfolio presentation

### Page Structure
- **Portfolio**: Main single-page layout with sections:
  - Hero section with animated introduction
  - About section with personal information
  - Projects showcase with filtering capabilities
  - Skills visualization with progress indicators
  - Experience timeline with education and internships
  - Contact form with validation

## Data Flow

1. **Client-Side Rendering**: React components render portfolio content statically
2. **API Communication**: Contact form submissions sent to `/api/contact` endpoint
3. **Form Validation**: Client-side validation before server submission
4. **Server Processing**: Express routes handle form submissions and file downloads
5. **User Feedback**: Toast notifications for user interactions

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **framer-motion**: Animation library
- **@radix-ui/***: Headless UI component primitives

### Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type checking and enhanced development experience
- **Tailwind CSS**: Utility-first CSS framework
- **ESBuild**: Fast JavaScript bundler for production

### Database Schema
The application includes a basic user schema using Drizzle ORM:
- Users table with id, username, and password fields
- PostgreSQL dialect configured for Neon serverless database
- Migration support through drizzle-kit

## Deployment Strategy

### Development Environment
- Vite development server with hot module replacement
- Express server running on Node.js with tsx for TypeScript execution
- Database migrations handled through `drizzle-kit push` command

### Production Build
- Client-side build outputs to `dist/public` directory
- Server-side build using ESBuild targeting Node.js
- Static asset serving through Express in production
- Environment variable configuration for database connection

### Scripts
- `dev`: Development mode with TypeScript execution
- `build`: Production build for both client and server
- `start`: Production server execution
- `check`: TypeScript type checking
- `db:push`: Database schema synchronization

## Changelog

Changelog:
- July 01, 2025. Initial setup
- July 01, 2025. Portfolio website completed with improved timeline design and resume download functionality

## User Preferences

Preferred communication style: Simple, everyday language.